insert into entrada_de_dinheiro	 values
(default, "01/02/2024", "Testando o teste", 190.90),
(default, "01/02/2024", "Testando o teste", 1900.90),
(default, "01/02/2024", "Testando o teste", 1000.90),
(default, "01/02/2024", "Testando o teste", 190000.90);