/*
  Warnings:

  - You are about to alter the column `valorServico` on the `backlogservices` table. The data in that column could be lost. The data in that column will be cast from `VarChar(191)` to `Double`.
  - You are about to alter the column `custoServico` on the `backlogservices` table. The data in that column could be lost. The data in that column will be cast from `VarChar(191)` to `Double`.
  - You are about to alter the column `valorProposta` on the `propostas` table. The data in that column could be lost. The data in that column will be cast from `VarChar(191)` to `Double`.
  - You are about to alter the column `custoProposta` on the `propostas` table. The data in that column could be lost. The data in that column will be cast from `VarChar(191)` to `Double`.

*/
-- AlterTable
ALTER TABLE `backlogservices` MODIFY `valorServico` DOUBLE NOT NULL,
    MODIFY `custoServico` DOUBLE NOT NULL;

-- AlterTable
ALTER TABLE `propostas` MODIFY `valorProposta` DOUBLE NOT NULL,
    MODIFY `custoProposta` DOUBLE NOT NULL;
