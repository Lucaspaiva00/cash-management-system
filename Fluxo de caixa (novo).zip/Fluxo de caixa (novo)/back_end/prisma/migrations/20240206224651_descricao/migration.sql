-- CreateTable
CREATE TABLE `Propostas` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `nomeProposta` VARCHAR(191) NOT NULL,
    `descricaoProposta` VARCHAR(191) NOT NULL,
    `prazoproposta` DATETIME(3) NOT NULL,
    `valorProposta` VARCHAR(191) NOT NULL,
    `custoProposta` VARCHAR(191) NOT NULL,
    `statusproposta` VARCHAR(191) NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `BacklogServices` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `nomeServi` VARCHAR(191) NOT NULL,
    `descricaoServico` VARCHAR(191) NOT NULL,
    `prazoServico` DATETIME(3) NOT NULL,
    `valorServico` VARCHAR(191) NOT NULL,
    `custoServico` VARCHAR(191) NOT NULL,
    `statusServico` VARCHAR(191) NOT NULL,
    `desevolvedorservico` VARCHAR(191) NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
