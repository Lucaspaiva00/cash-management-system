-- AlterTable
ALTER TABLE `propostas` MODIFY `prazoproposta` VARCHAR(191) NOT NULL;
