const produtosCadastrados = document.querySelector("#produtosCadastrados");
const uri = "http://localhost:3000";

fetch("http://localhost:3000/produtos")
    .then(resp => resp.json())
    .then(resp => {
        resp.forEach(e => {
            produtosCadastrados.innerHTML +=
                `
        <tr>
            <td>${e.nomeProduto}</td>
            <td>${e.descricaoProduto}</td>
            <td>${e.quantidadeProduto}</td>
            <td>${e.valorProduto}</td>
            <td>${e.custoProduto}</td>
            <td>${e.statusProduto}</td>
            <td>                
            <button type="button" title="button" class='btn btn-primary' id='editaroperacao' onClick='editaroperacao(${e.id})'>Editar</button>
            <button type="button" title="button" class='btn btn-primary' id='excluirProduto' onClick='excluirProduto(${e.id})'>Excluir</button>
            </td>
        <tr>
        `;
            console.table(produtosCadastrados)
        });

    });

function excluirProduto(id) {
    if (confirm(`Confirma a exclusão do seu Cliente?`)) {
        fetch(uri + "/produtos/" + id, { method: "DELETE" })
            .then((resp) => {
                if (resp.status != 204) {
                    return {
                        error: "Erro ao excluir comentário",
                    };
                } else return {};
            })
            .then((resp) => {
                if (resp.error == undefined) {
                    window.location.reload();
                } else {
                    document.querySelector("#msg").innerHTML = resp.error;
                }
            });
    }
}