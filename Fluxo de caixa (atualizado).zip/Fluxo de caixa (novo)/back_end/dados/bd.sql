insert into gerenciamentoDcaixa	 values
(default, "01/02/2024", "Testando o teste", 190.90),
(default, "01/02/2024", "Testando o teste", 1900.90),
(default, "01/02/2024", "Testando o teste", 1000.90),
(default, "01/02/2024", "Testando o teste", 190000.90);

insert into clientes values 
(default, "Lucas Paiva", "47.051.253/000158", "397.128.398-50", "50.750.667-4", "Mario Zarpelon", "(19)99689-2382", "paival907@gmail.com", "13920-000", "195", "casa", "Teste", "Testando");
